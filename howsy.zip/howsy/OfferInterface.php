<?php

interface OfferInterface {

    public function apply(Basket $basket);

}